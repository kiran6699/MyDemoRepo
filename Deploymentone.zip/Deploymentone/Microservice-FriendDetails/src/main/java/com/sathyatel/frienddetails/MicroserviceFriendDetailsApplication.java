package com.sathyatel.frienddetails;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroserviceFriendDetailsApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroserviceFriendDetailsApplication.class,args);
	}

}
